import React from "react";
import Zegar from "./Zegar";

class App extends React.Component{
    render(){
        return(
            <div>
                <Zegar/>
            </div>
        )
    }
}

export default App;